================================================================================
UNDERSTANDING FoodOrder AS A STATE MACHINE
A Guide for Your First Complex Project
================================================================================

Let me explain these concepts from the ground up, with simple examples.

================================================================================
PART 1: What is a "State Machine"? (Simple Explanation)
================================================================================

Think of an Order like a Vending Machine with buttons:

┌─────────────────────────────────────────────────────┐
│  VENDING MACHINE (The Order's Life)                 │
├─────────────────────────────────────────────────────┤
│                                                     │
│  [START] "Pending"                                  │
│     ↓ (Customer pays)                               │
│  "Confirmed"                                        │
│     ↓ (Restaurant starts cooking)                   │
│  "Cooking"                                          │
│     ↓ (Driver picks up)                             │
│  "In Transit"                                       │
│     ↓ (Customer gets it)                            │
│  "Delivered" [END]                                  │
│                                                     │
│  OR at any point:                                   │
│     ↓ (Customer/Restaurant cancels)                 │
│  "Cancelled" [END]                                  │
│                                                     │
└─────────────────────────────────────────────────────┘

KEY POINT: An order can only move FORWARD through states (or be cancelled).
You can't go from "Delivered" back to "Cooking".
You can't skip from "Pending" directly to "In Transit".

This is different from a Customer Profile, which is more flexible:
- Customer profile: You can change name, address anytime (no "flow")
- Order: It flows through states (strict "flow")


================================================================================
PART 2: Question 1 - Update Strategy
"Field Dump" vs. "State Transitions"
================================================================================

WHAT IS "FIELD DUMP"?

A generic update() that looks like this:

    public function update($data) {
        // $data contains: ["total_amount" => 50, "status" => "Delivered", ...]
        // We update everything blindly
        $query = "UPDATE food_order SET total_amount = ?, status = ? WHERE id = ?";
        // ... execute
    }

THE PROBLEM WITH "FIELD DUMP":

Imagine a Driver calls the update() endpoint with this data:
    {
        "order_id": 42,
        "status": "Delivered",
        "total_amount": 5.00    // <-- Oops! Changed from $50 to $5!
    }

The update() function doesn't check—it just changes everything.
Now the restaurant lost $45. Bad!


BETTER APPROACH: "State Transitions" (Specific Methods)

Instead of one generic update(), create specific methods for each action:

    public function assignDriver($order_id, $driver_id) {
        // Only updates: driver_id, status -> "In Transit"
        // Can't touch total_amount or items
    }

    public function updateStatus($order_id, $new_status) {
        // Only updates: status (and validates the transition)
        // Pending -> Confirmed (OK)
        // Pending -> Delivered (NOT OK - can't skip steps)
    }

    public function cancelOrder($order_id) {
        // Only updates: status -> "Cancelled"
        // Deletes nothing, keeps financial record
    }

WHY IS THIS SAFER?

Each method has a single responsibility:
- assignDriver() = only driver assignment (safe)
- updateStatus() = only status changes (safe)
- cancelOrder() = only cancellation (safe)

A Driver can't accidentally change total_amount because that method doesn't exist.

---

MY RECOMMENDATION:

✅ Use SPECIFIC HELPER METHODS (State Transitions)

Methods you should create:

    public function assignDriver($order_id, $driver_id)
    public function updateStatus($order_id, $new_status)  // With validation!
    public function cancelOrder($order_id)
    
    // Probably NOT needed:
    public function update($data)  // Don't create this one


================================================================================
PART 3: Question 2 - Reading the "Basket" (The Join Problem)
================================================================================

WHAT IS THE PROBLEM?

When a customer asks "Show me my order #42", you need:

TABLE: food_order
┌────┬──────────────┬──────────┬─────────────┐
│ id │ customer_id  │ status   │ total_price │
├────┼──────────────┼──────────┼─────────────┤
│42  │ 10           │ Delivered│ 25.50       │
└────┴──────────────┴──────────┴─────────────┘

But this doesn't say WHAT was ordered! You need:

TABLE: order_items
┌────┬──────────┬──────────────┬──────────┬──────────┐
│ id │ order_id │ menu_item_id │ quantity │ price    │
├────┼──────────┼──────────────┼──────────┼──────────┤
│100 │ 42       │ 12           │ 2        │ 8.50     │  (2x Margarita)
│101 │ 42       │ 18           │ 1        │ 2.50     │  (1x Coke)
│102 │ 42       │ 20           │ 1        │ 4.99     │  (1x Garlic Bread)
└────┴──────────┴──────────────┴──────────┴──────────┘

So to show the customer their order, you need data from BOTH tables!


THE SOLUTION: A "Join" Query + Helper Method

Your read_single($order_id) should:

1. Query the food_order table (the main order info)
2. Use a PRIVATE helper method getOrderItems($order_id) to fetch items
3. Combine them into one response

Here's the flow:

    public function read_single($order_id) {
        // Step 1: Get the order itself
        $order = $this->getOrderData($order_id);
        
        // Step 2: Get the items in that order (using helper)
        $items = $this->getOrderItems($order_id);
        
        // Step 3: Combine into one response
        $order['items'] = $items;
        
        return $order;
    }

    // PRIVATE helper - only used internally
    private function getOrderItems($order_id) {
        $query = "SELECT 
                    oi.id,
                    oi.menu_item_id,
                    mi.name,
                    oi.quantity,
                    oi.price
                  FROM order_items oi
                  JOIN menu_item mi ON oi.menu_item_id = mi.id
                  WHERE oi.order_id = ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$order_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }


THE JSON RESPONSE LOOKS LIKE:

{
    "success": true,
    "data": {
        "id": 42,
        "customer_id": 10,
        "status": "Delivered",
        "total_price": 25.50,
        "items": [
            {
                "id": 100,
                "menu_item_id": 12,
                "name": "Margarita",
                "quantity": 2,
                "price": 8.50
            },
            {
                "id": 101,
                "menu_item_id": 18,
                "name": "Coke",
                "quantity": 1,
                "price": 2.50
            },
            {
                "id": 102,
                "menu_item_id": 20,
                "name": "Garlic Bread",
                "quantity": 1,
                "price": 4.99
            }
        ]
    }
}

WHY THIS IS IMPORTANT:

The frontend doesn't want to make 2 API calls. It asks for order #42,
and expects to get: order info + items + everything.

This is the standard pattern in REST APIs.


---

MY RECOMMENDATION:

✅ YES, include items in read_single() response

Create a private helper method getOrderItems() that does the JOIN.
This keeps your code organized and reusable.


================================================================================
PART 4: Question 3 - Deletion vs. Cancellation
================================================================================

THE PROBLEM WITH HARD DELETE:

Imagine you delete order #50:

    DELETE FROM food_order WHERE id = 50;

Now your database looks like:

    Order #49: $45.00
    Order #51: $30.00
    [Order #50 is gone]
    Order #52: $60.00

YOUR MANAGER ASKS: "What was our revenue yesterday?"

You calculate: 45 + 30 + 60 = $135

But the REAL revenue was: 45 + 50 + 30 + 60 = $185
(You lost $50 because order #50 disappeared!)

This is TERRIBLE for accounting and audits.


THE SOLUTION: SOFT CANCEL (Keep the data, mark as "Cancelled")

Instead of deleting, just change the status:

    UPDATE food_order SET order_status_id = (SELECT id FROM order_status WHERE name = 'Cancelled')
    WHERE id = 50;

Now your data still exists:

    Order #49: $45.00 (Delivered)
    Order #50: $50.00 (Cancelled)  <-- Still there!
    Order #51: $30.00 (Delivered)
    Order #52: $60.00 (Delivered)

Revenue calculation: 45 + 50 + 30 + 60 = $185 ✓ Correct!

When displaying orders to the customer, you just filter out "Cancelled" orders.


WHY SOFT CANCEL IS BETTER:

1. Financial Records: Nothing disappears, revenue is always accurate
2. Audit Trail: You can see what was cancelled and when
3. Customer Service: Support can say "Why was my order cancelled?" and see the data
4. Debugging: If there's a bug that cancels orders, you have evidence


SPECIAL CASE: Empty Orders

What if an order was created but never confirmed (still "Pending")?
Can you delete it?

Probably yes, but only if:
- It's been pending for more than 30 minutes, OR
- Only the restaurant owner can delete it (not customers/drivers)

Better approach: Set a rule like:
"Orders can only be cancelled (status = 'Cancelled'), never deleted"

This is simpler and safer.


---

MY RECOMMENDATION:

✅ Use SOFT CANCEL (Option B)

Create a cancelOrder() method:

    public function cancelOrder($order_id, $reason = null) {
        // Update status to "Cancelled"
        // Don't delete anything
        // Optionally store the cancellation reason
    }

NEVER expose a delete() endpoint for orders.
Orders are financial records and should never be destroyed.


================================================================================
SUMMARY TABLE: Your Decisions
================================================================================

QUESTION 1 - Update Strategy:
  ✅ CHOICE: Specific Helper Methods (State Transitions)
  METHODS: assignDriver(), updateStatus(), cancelOrder()
  NOT: A generic update()

QUESTION 2 - Reading the "Basket":
  ✅ CHOICE: Include items in read_single() response
  METHOD: Create private getOrderItems() helper for the JOIN

QUESTION 3 - Deletion vs. Cancellation:
  ✅ CHOICE: Soft Cancel (Soft Delete Pattern)
  METHOD: cancelOrder() just changes status to "Cancelled"
  NEVER expose delete() for orders


================================================================================
NEXT STEPS: Build the State Machine
================================================================================

With these decisions made, we're ready to code:

1. Create the Order class with helper methods
2. Implement status validation (e.g., can't go Pending -> Delivered)
3. Build the API endpoints that call these methods
4. Test edge cases (what if driver cancels while cooking?)

Ready to start coding?
